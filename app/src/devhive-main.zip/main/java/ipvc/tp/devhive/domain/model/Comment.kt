package ipvc.tp.devhive.domain.model

import java.util.Date

/**
 * Modelo de domínio para representar um comentário
 */
data class Comment(
    val id: String,
    val materialId: String,
    val userUid: String,
    val content: String,
    val createdAt: Date,
    val updatedAt: Date,
    val likes: Int,
    val parentCommentId: String?,
    val attachments: List<Attachment>
)

data class Attachment(
    val type: String,
    val url: String
)
