package ipvc.tp.devhive.data.util

object SyncStatus {
    const val SYNCED = "SYNCED"
    const val PENDING_UPLOAD = "PENDING_UPLOAD"
    const val PENDING_UPDATE = "PENDING_UPDATE"
    const val PENDING_DELETE = "PENDING_DELETE"
    const val SYNC_ERROR = "SYNC_ERROR"
}
