package ipvc.tp.devhive.presentation.viewmodel.studygroup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class StudyGroupViewModelFactory : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudyGroupViewModel::class.java)) {
            return StudyGroupViewModel() as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
