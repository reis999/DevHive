package ipvc.tp.devhive.domain.model

import java.util.Date

/**
 * Modelo de domínio para representar um chat
 */
data class Chat(
    val id: String,
    val name: String,
    val isPrivate: Boolean,
    val accessCode: String,
    val maxCapacity: Int,
    val participantIds: List<String>,
    val creatorUid: String,
    val createdAt: Date,
    val updatedAt: Date,
    val lastMessageAt: Date,
    val lastMessagePreview: String,
    val messageCount: Int
)
