package ipvc.tp.devhive.domain.model

import java.util.Date

/**
 * Modelo de domínio para representar um grupo de estudo
 */
data class StudyGroup(
    val id: String,
    val name: String,
    val description: String,
    val createdBy: String,
    val createdAt: Date,
    val updatedAt: Date,
    val imageUrl: String,
    val members: List<String>,
    val admins: List<String>,
    val categories: List<String>,
    val isPrivate: Boolean,
    val joinCode: String
)
